# xfce-alt-scroll (C prototype, v0.1.0)

Small native X11 tool for XFCE `Alt + two-finger touchpad scroll` desktop zoom, without passing smooth scrolling to GTK, Electron or virtual-machine windows.

**Status:** compiled; **not yet tested on your ASUS hardware**. C port of a working Python experiment. This version supports auto-discovered **touchpads only**, not physical mouse wheels. Neither Wayland nor other window managers are supported. The `.deb` is an experimental build for Debian Bookworm/MX Linux or newer on amd64, not an official Xfce package.

## How it works

- Enumerates `/dev/input/event*` (event node numbers are not hard-coded); selects a multitouch device whose evdev name contains `Touchpad`.
- Maps its name to the matching XInput device, saves `libinput Scroll Method Enabled`.
- While Alt is held, sets that property to `0 0 0`, reads `ABS_MT_POSITION_Y` for two fingers from evdev and converts every 2 mm of motion into a single XTest button 4/5 event, at most every 5 milliseconds.
- When Alt is released or the tool exits normally, restores the original scroll method. No queued zoom events.
- Polls for changes/reconnection. Uses one touchpad at a time (typical laptop).

The stateful evdev/XTest approach prevents the stutter caused by spawning `xdotool` for every event.

## Installing

1. Stop the original Python script. Re-enable original scrolling if necessary.
2. Install the package: `sudo apt install ./xfce-alt-scroll_0.1.0-1_amd64.deb` (or `sudo dpkg -i ...` when dependencies are already present).
3. **Sign out and in again** to allow the udev `uaccess` rule to grant active seat users permission to read touchpad evdev events, and to start the XFCE session autostart. A reboot also works.
4. Test `Alt + two-finger scroll` in `xfce4-terminal`, ChatGPT, and the VM.

The package installs a udev rule matching **touchpads only** and an XFCE-only XDG autostart entry. It does not require running the graphical program as root. Reading raw touchpad events requires ACL access to the device.

Manual foreground test:

```
xfce-alt-scroll --verbose
```

Default tuning matches the tested Python prototype: `--step-mm 2 --interval-ms 5`. For reverse zoom use `--invert`.

## Emergency / rollback

Stop with Ctrl+C in a foreground session. The original scroll method is restored on SIGTERM and SIGINT as well. SIGKILL or power loss does *not* permit cleanup. In that case, restore with `xinput` using the current device ID:

```
xinput list --short
xinput set-prop <TOUCHPAD_ID> 'libinput Scroll Method Enabled' 1 0 0
```

`1 0 0` reflects the user's original two-finger-scrolling configuration; on a different machine use its previously recorded values.

Disable auto-start without uninstalling:

```
mkdir -p ~/.config/autostart
printf '[Desktop Entry]\nType=Application\nName=xfce-alt-scroll\nHidden=true\n' > ~/.config/autostart/xfce-alt-scroll.desktop
```

Uninstall: `sudo apt remove xfce-alt-scroll`, then log out and in. The package never patches `xfwm4`.

## Known limitations

- Mouse-wheel-only desktops are **not fixed** by this v0.1 C port. Upstream `xfwm4` fix should be considered separately.
- Uses `xinput` executable to set the property on each Alt state transition. That operation is intentionally outside the high-frequency gesture path, which uses direct XTest.
- Requires readable `/dev/input/event*` touchpad node, and an XInput device with the `libinput Scroll Method Enabled` property. Matching by device name is not yet robust for two touchpads with identical names.
- Some early/delayed touch frames may be lost at gesture start. Threshold is 2mm by default.
- Only basic compile/runtime sanity checks have been performed in a build container; actual touchpad, Xorg and XFCE integration must be tested on the target machine.

## Build

```
make
sudo make install
```

For portable distro builds, a native per-distro build is preferable. The released amd64 build was checked to require no libc symbol newer than GLIBC_2.34 (Debian 12 glibc is 2.36).
